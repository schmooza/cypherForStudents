def addOne(wordIs):
    # add 1 to the number.
    keyIs = 1
    wordIs = wordIs + keyIs
    return wordIs, keyIs