def deleteOne(secretNumber):
    
    # delete 1 from the number.
    
    secretNumberInt = int(secretNumber)
    # print(type(secretNumberInt),"degub22")
    originalNumber = secretNumberInt -1
    # print(originalNumber,"debug 44")

    return originalNumber


