def deleteOne(secretNumber):
    # delete 1 from the number.
    originalNumber = secretNumber -1
    return originalNumber


