def addOne(wordIs):
    # add 1 to the number.
    wordIs = wordIs + 1
    return wordIs